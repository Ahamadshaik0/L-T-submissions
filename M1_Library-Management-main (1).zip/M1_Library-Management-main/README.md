# M1_Library-Management

![codiga Score](https://api.codiga.io/project/32271/score/svg)
![codiga Grade](https://api.codiga.io/project/32271/status/svg)

[![Codacy Badge](https://app.codacy.com/project/badge/Grade/8d3fbf28ac154572bedd91f75f8e6718)](https://www.codacy.com/gh/Balaveeraseshu/M1_Library-Management/dashboard?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=Balaveeraseshu/M1_Library-Management&amp;utm_campaign=Badge_Grade)

[![Code Quality - Cppcheck](https://github.com/Balaveeraseshu/M1_Library-Management/actions/workflows/c-cpp.yml/badge.svg)](https://github.com/Balaveeraseshu/M1_Library-Management/actions/workflows/c-cpp.yml)

[![Analysis](https://github.com/Balaveeraseshu/M1_Library-Management/actions/workflows/Analysis.yml/badge.svg)](https://github.com/Balaveeraseshu/M1_Library-Management/actions/workflows/Analysis.yml)


[![Bulid CI - windows](https://github.com/Balaveeraseshu/M1_Library-Management/actions/workflows/Windows.yml/badge.svg)](https://github.com/Balaveeraseshu/M1_Library-Management/actions/workflows/Windows.yml)


[![Build_CI - Linux](https://github.com/Balaveeraseshu/M1_Library-Management/actions/workflows/Linux.yml/badge.svg)](https://github.com/Balaveeraseshu/M1_Library-Management/actions/workflows/Linux.yml)
