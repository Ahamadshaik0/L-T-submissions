# M1_Library_Management

# Introduction
This project is about to managing the library operations and kepping recoeds more easly better way. 
The File handling technique is used to store the data of the books in a specific file. 
You can perform the operations like returning book, storing book and student details, issue book details. 
In fact, you can do operations like Real Library operations.
By using this we can track the records of books issuing, adding books, removing book and searching book etc are easily.

# Features of Library Management
Add Books- For the add books, we can add information about new books into the system. Delete books- By this we can remove a paraticular book information after a book was removed from list. Search books- By this we can search that a book is exsists or not in library. Issue Books-By this we can issue a book to a student by noting his details. And also we can view the list of books that are available in library and we can edit records of books.



# WHO
College or University management

# WHAT
To manage the library system more easily

# WHEN
Like issuing the books to students and handovering the books

#  WHERE
Colleges, Universities

# HOW 
By installing software that provide the interface of this management
