# Traffic light control
![image](https://user-images.githubusercontent.com/94268410/144428784-02c9b39c-05fb-4c3e-88ee-dacf8602589d.png)

![image](https://user-images.githubusercontent.com/94268410/144353787-cf8e8af2-bad1-4f56-a761-b1fbdf92eb24.png)
