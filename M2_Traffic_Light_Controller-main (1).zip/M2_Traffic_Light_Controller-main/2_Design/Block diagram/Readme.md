![Block Diagram](https://user-images.githubusercontent.com/94268410/144398995-51c32bd6-8d14-4727-bb4a-efe36cf72ae0.png)


