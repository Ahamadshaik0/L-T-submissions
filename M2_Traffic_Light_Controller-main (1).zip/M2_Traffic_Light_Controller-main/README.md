# M2_Traffic_Light_Controller

![Codiga Score](https://api.codiga.io/project/32939/score/svg)

![Codiga Grade](https://api.codiga.io/project/32939/status/svg)

[![Codacy Badge](https://app.codacy.com/project/badge/Grade/7276eb2efcc7489cbae7854e2a494a5e)](https://www.codacy.com/gh/Balaveeraseshu/M2_Traffic_Light_Controller/dashboard?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=Balaveeraseshu/M2_Traffic_Light_Controller&amp;utm_campaign=Badge_Grade)

[![Code Quality - Cppcheck](https://github.com/Balaveeraseshu/M2_Traffic_Light_Controller/actions/workflows/Cpp.yml/badge.svg)](https://github.com/Balaveeraseshu/M2_Traffic_Light_Controller/actions/workflows/Cpp.yml)

[![Build_CI - Linux](https://github.com/Balaveeraseshu/M2_Traffic_Light_Controller/actions/workflows/Linux.yml/badge.svg)](https://github.com/Balaveeraseshu/M2_Traffic_Light_Controller/actions/workflows/Linux.yml)

[![Bulid CI - windows](https://github.com/Balaveeraseshu/M2_Traffic_Light_Controller/actions/workflows/Windows.yml/badge.svg)](https://github.com/Balaveeraseshu/M2_Traffic_Light_Controller/actions/workflows/Windows.yml)

[![Git Inspector](https://github.com/Balaveeraseshu/M2_Traffic_Light_Controller/actions/workflows/Git%20Inspector.yml/badge.svg)](https://github.com/Balaveeraseshu/M2_Traffic_Light_Controller/actions/workflows/Git%20Inspector.yml)

## Folder Structure
Folder             | Description
-------------------| -----------------------------------------
`0_Abstract`       | About Project
`1_Requirements`   | Documents containing requirements 
`2_Design`         | Documents specifying design details of circuit
`3_Implementation` | All required codes and documentation
`4_TestPlanAndOutput`      | low and High level Requirements
`5_Report`         | Report all the details about project
`6_Output`         | Documents with simulation Images

## Learning Platforms
* Youtube
* future skills
* geeks for geeks
