## Flow chart of the wiper system

![flowwiper](https://user-images.githubusercontent.com/101174057/167923605-5b7a6dcc-20da-40a4-923f-0bb71637ba14.png)


## Model of how the wiper works in the car

![twinwiper](https://user-images.githubusercontent.com/101174057/167924189-27ccfcee-33d4-492a-929f-ec02c609891d.gif)

## Structural diagram of the wiper system

![structural](https://user-images.githubusercontent.com/101174057/167923856-3066018e-aab3-4bb1-ab80-f976023ccdec.png)
