# M3_Wiper_Control_System

# TEST PLAN
## High level test plan
| ID | Description | Expected O/P | Actual O/P | Type of test |
| --- | --- | --- | --- | --- |
| H_01 | Wiper is moving along the windshield	| PASSED | SUCCESS | Scenario |
| H_02 | Wiper is comes to rest at the end |	PASSED |	SUCCESS |	Boundary|

## Low level test plan
| ID | Description | Expected O/P | Actual O/P | Type of test |
| --- | --- | --- | --- | --- |
| L_01 | Car turned on	| PASSED | SUCCESS | Scenario |
| L_02 | Car turned off |	PASSED |	SUCCESS |	Boundary|
